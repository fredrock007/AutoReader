# AutoReader

An experimental mobile-friendly React app that detects printed English text with the camera and reads it aloud after saying “About to read text. Three, two, one.”

## Run locally
```bash
npm install
npm run dev
```
Open the Vite URL. Mobile camera access requires HTTPS (or localhost). Browser speech synthesis support varies.

## Current limitations
- Prototype, not yet tested on an OPPO phone.
- OCR runs periodically and may be slow on older devices.
- A passage must be detected twice with identical normalized text to start reading; real OCR output can fluctuate.
- Word-by-word speech synthesis is a basic highlighting workaround and can sound unnatural.
- Pause/resume behaviour varies by browser.
- No reading queue yet; new text is checked after the current reading.
- No GitHub repository has been created or published.
