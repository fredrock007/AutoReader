import React,{useEffect,useRef,useState} from "react";
import Tesseract from "tesseract.js";
export default function App(){
 const video=useRef(null),stream=useRef(null),busy=useRef(false),last=useRef(""),current=useRef(""),reading=useRef(false),cancelled=useRef(false);
 const [status,setStatus]=useState("Camera off"),[text,setText]=useState(""),[index,setIndex]=useState(-1),[running,setRunning]=useState(false),[rate,setRate]=useState(1);
 const rateRef=useRef(1);useEffect(()=>{rateRef.current=rate},[rate]);
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const speak=(message)=>new Promise(resolve=>{if(!("speechSynthesis"in window)){resolve();return;}const u=new SpeechSynthesisUtterance(message);u.rate=rateRef.current;u.onend=resolve;u.onerror=resolve;window.speechSynthesis.speak(u)});
 async function read(t){if(reading.current||cancelled.current)return;reading.current=true;current.current=t;setText(t);setIndex(-1);
  setStatus("Countdown");await speak("About to read text");for(const n of ["three","two","one"]){if(cancelled.current)break;await speak(n)}
  if(!cancelled.current){setStatus("Reading");const words=t.match(/\S+\s*/g)||[];for(let i=0;i<words.length&&!cancelled.current;i++){setIndex(i);await speak(words[i])}}
  last.current=t;reading.current=false;setIndex(-1);setStatus(cancelled.current?"Stopped":"Looking for new text");
 }
 async function scan(){if(!video.current||busy.current||reading.current||cancelled.current)return;busy.current=true;
 try{const c=document.createElement("canvas");c.width=video.current.videoWidth;c.height=video.current.videoHeight;if(!c.width||!c.height)return;c.getContext("2d").drawImage(video.current,0,0);const r=await Tesseract.recognize(c,"eng");const found=r.data.text.replace(/\s+/g," ").trim();if(found.length>25&&found!==last.current){if(found===current.current){await read(found)}else{current.current=found;setStatus("Confirming stable text")}}}
 catch(e){setStatus("OCR error: "+e.message)}finally{busy.current=false}}
 async function start(){try{cancelled.current=false;const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"},audio:false});stream.current=s;video.current.srcObject=s;await video.current.play();setRunning(true);setStatus("Looking for text")}catch(e){setStatus("Camera unavailable: "+e.message)}}
 function stop(){cancelled.current=true;window.speechSynthesis?.cancel();stream.current?.getTracks().forEach(t=>t.stop());stream.current=null;setRunning(false);setStatus("Stopped")}
 useEffect(()=>{if(!running)return;const timer=setInterval(scan,2500);return()=>clearInterval(timer)},[running]);
 useEffect(()=>()=>{stream.current?.getTracks().forEach(t=>t.stop());window.speechSynthesis?.cancel()},[]);
 const words=text.match(/\S+\s*/g)||[];
 return <main><h1>AutoReader</h1><p>Point your camera at printed text. Reading begins after a spoken countdown.</p><video ref={video} muted playsInline autoPlay/><p role="status">{status}</p><div className="controls"><button onClick={running?stop:start}>{running?"Stop camera":"Start camera"}</button><button onClick={()=>window.speechSynthesis?.pause()}>Pause voice</button><button onClick={()=>window.speechSynthesis?.resume()}>Resume voice</button></div><label>Speech speed <input type="range" min=".6" max="1.6" step=".1" value={rate} onChange={e=>setRate(Number(e.target.value))}/>{rate}×</label><section aria-live="off"><h2>Detected text</h2>{words.map((w,i)=><span key={i} className={index===i?"active":""}>{w}</span>)}</section></main>
}